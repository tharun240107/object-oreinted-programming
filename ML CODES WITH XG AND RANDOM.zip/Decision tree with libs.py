# ID3, C4.5 and CART Decision Tree Comparison on the Iris dataset
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score

# Load and split the data
X, y = load_iris(return_X_y=True)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# ID3: uses entropy (information gain)
id3 = DecisionTreeClassifier(criterion="entropy", random_state=42)
id3.fit(X_train, y_train)
print("ID3 Accuracy :", accuracy_score(y_test, id3.predict(X_test)))

# C4.5: uses entropy plus pruning (sklearn has no gain ratio)
c45 = DecisionTreeClassifier(criterion="entropy", ccp_alpha=0.01, random_state=42)
c45.fit(X_train, y_train)
print("C4.5 Accuracy:", accuracy_score(y_test, c45.predict(X_test)))

# CART: uses the Gini index
cart = DecisionTreeClassifier(criterion="gini", random_state=42)
cart.fit(X_train, y_train)
print("CART Accuracy:", accuracy_score(y_test, cart.predict(X_test)))