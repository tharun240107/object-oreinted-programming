import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score

df = pd.read_csv("data.csv")

X = df.iloc[:,:-1].values
y = df.iloc[:,-1].values

u = np.unique(y)
y = np.where(y == u[0],0,1)

Xtr,Xt,ytr,yt = train_test_split(X,y,test_size=0.2,random_state=42,stratify=y)

sc = StandardScaler()
Xtr = sc.fit_transform(Xtr)
Xt = sc.transform(Xt)

def relu(x):
    return np.maximum(0,x)

def relu_derivative(x):
    return (x > 0).astype(float)

def sigmoid(x):
    return 1/(1+np.exp(-np.clip(x,-500,500)))

def train(X,y,hidden=10,lr=0.001,epochs=1000):
    np.random.seed(42)

    W1 = np.random.randn(X.shape[1],hidden)*0.01
    b1 = np.zeros(hidden)
    W2 = np.random.randn(hidden,1)*0.01
    b2 = 0

    for epoch in range(epochs):
        z1 = X@W1+b1
        a1 = relu(z1)
        z2 = a1@W2+b2
        a2 = sigmoid(z2).ravel()

        error = a2-y

        dW2 = a1.T@error.reshape(-1,1)/len(X)
        db2 = np.mean(error)

        d1 = error.reshape(-1,1)@W2.T
        d1 = d1*relu_derivative(z1)

        dW1 = X.T@d1/len(X)
        db1 = np.mean(d1,axis=0)

        W2 -= lr*dW2
        b2 -= lr*db2
        W1 -= lr*dW1
        b1 -= lr*db1

    return W1,b1,W2,b2

def predict(X,W1,b1,W2,b2):
    a1 = relu(X@W1+b1)
    p = sigmoid(a1@W2+b2).ravel()
    return (p >= 0.5).astype(int)

# Main Model
W1,b1,W2,b2 = train(Xtr,ytr)
pred = predict(Xt,W1,b1,W2,b2)

print("Actual   :",list(yt))
print("Predicted:",list(pred))
print("Accuracy :",accuracy_score(yt,pred))

# Hidden Layers / Neurons
print("\nHidden Neurons Analysis")
for h in [5,10,20]:
    w1,b1,w2,b2 = train(Xtr,ytr,hidden=h)
    p = predict(Xt,w1,b1,w2,b2)
    print("Hidden Neurons:",h,"Accuracy:",accuracy_score(yt,p))

# Learning Rate
print("\nLearning Rate Analysis")
for lr in [0.0001,0.001,0.1]:
    w1,b1,w2,b2 = train(Xtr,ytr,lr=lr)
    p = predict(Xt,w1,b1,w2,b2)
    print("LR:",lr,"Accuracy:",accuracy_score(yt,p))

# Epochs
print("\nEpoch Analysis")
for ep in [100,500,1000]:
    w1,b1,w2,b2 = train(Xtr,ytr,epochs=ep)
    p = predict(Xt,w1,b1,w2,b2)
    print("Epochs:",ep,"Accuracy:",accuracy_score(yt,p))