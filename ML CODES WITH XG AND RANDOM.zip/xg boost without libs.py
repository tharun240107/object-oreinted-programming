import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

df = pd.read_csv("data.csv")

X = df.iloc[:, :-1].values
y = df.iloc[:, -1].values

# Encode labels
labels = np.unique(y)
y = np.array([np.where(labels == v)[0][0] for v in y])

# Train-Test Split
Xtr, Xt, ytr, yt = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Sigmoid Function
def sigmoid(x):
    x = np.clip(x, -500, 500)
    return 1 / (1 + np.exp(-x))

# Find Best Split
def best_split(X, g, h, lam=1):

    best_gain = -float("inf")
    best_feature = None
    best_value = None
    best_left = 0
    best_right = 0

    G = np.sum(g)
    H = np.sum(h)

    for feature in range(X.shape[1]):

        for value in np.unique(X[:, feature]):

            left = X[:, feature] <= value
            right = X[:, feature] > value

            if np.sum(left) == 0 or np.sum(right) == 0:
                continue

            GL = np.sum(g[left])
            HL = np.sum(h[left])

            GR = np.sum(g[right])
            HR = np.sum(h[right])

            gain = 0.5 * (
                GL**2 / (HL + lam)
                + GR**2 / (HR + lam)
                - G**2 / (H + lam)
            )

            if gain > best_gain:

                best_gain = gain
                best_feature = feature
                best_value = value

                best_left = -GL / (HL + lam)
                best_right = -GR / (HR + lam)

    return best_feature, best_value, best_left, best_right

# Predict Using One Tree
def predict_tree(tree, X):

    feature, value, left, right = tree

    return np.where(
        X[:, feature] <= value,
        left,
        right
    )

# Parameters
learning_rate = 0.1
lam = 1
n_trees = 10

# Initial Predictions
Ftr = np.zeros(len(Xtr))
Ftest = np.zeros(len(Xt))

trees = []

# Boosting
for i in range(n_trees):

    # Calculate probability
    p = sigmoid(Ftr)

    # Calculate gradient and Hessian
    g = p - ytr
    h = p * (1 - p)

    # Build tree
    tree = best_split(
        Xtr, g, h, lam
    )

    trees.append(tree)

    # Update training predictions
    Ftr += learning_rate * predict_tree(
        tree, Xtr
    )

# Test Prediction
for tree in trees:

    Ftest += learning_rate * predict_tree(
        tree, Xt
    )

# Convert scores to probabilities
prob = sigmoid(Ftest)

# Convert probabilities to class labels
pred = (prob >= 0.5).astype(int)

# Results
print("Actual   :", yt)
print("Predicted:", pred)
print("Accuracy :", accuracy_score(yt, pred))