import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

df = pd.read_csv("data.csv")

X = df.iloc[:, :-1].values
y = df.iloc[:, -1].values

# Encode labels
labels = np.unique(y)
y = np.array([np.where(labels == v)[0][0] for v in y])

# Train-Test Split
Xtr, Xt, ytr, yt = train_test_split(
    X, y, test_size=0.2, random_state=42
)


# Gini Impurity
def gini(y):
    _, counts = np.unique(y, return_counts=True)
    p = counts / len(y)
    return 1 - np.sum(p ** 2)


# Find Best Split
def best_split(X, y, features):

    best_score = float("inf")
    best_feature = None
    best_value = None

    for feature in features:

        for value in np.unique(X[:, feature]):

            left = y[X[:, feature] <= value]
            right = y[X[:, feature] > value]

            if len(left) == 0 or len(right) == 0:
                continue

            score = (
                len(left) / len(y) * gini(left)
                + len(right) / len(y) * gini(right)
            )

            if score < best_score:
                best_score = score
                best_feature = feature
                best_value = value

    return best_feature, best_value


# Build Decision Tree
def build_tree(X, y, depth=0, max_depth=4):

    if len(np.unique(y)) == 1 or depth == max_depth:
        return np.bincount(y).argmax()

    n_features = max(1, int(np.sqrt(X.shape[1])))

    features = np.random.choice(
        X.shape[1], n_features, replace=False
    )

    feature, value = best_split(X, y, features)

    if feature is None:
        return np.bincount(y).argmax()

    left = X[:, feature] <= value
    right = X[:, feature] > value

    return (
        feature,
        value,
        build_tree(X[left], y[left], depth + 1, max_depth),
        build_tree(X[right], y[right], depth + 1, max_depth)
    )


# Predict using one tree
def predict_tree(tree, x):

    if not isinstance(tree, tuple):
        return tree

    feature, value, left, right = tree

    if x[feature] <= value:
        return predict_tree(left, x)
    else:
        return predict_tree(right, x)


# Build Random Forest
trees = []

for i in range(10):

    # Bootstrap sample
    idx = np.random.choice(
        len(Xtr), len(Xtr), replace=True
    )

    tree = build_tree(
        Xtr[idx],
        ytr[idx]
    )

    trees.append(tree)


# Majority Voting
pred = []

for x in Xt:

    votes = []

    for tree in trees:
        votes.append(predict_tree(tree, x))

    pred.append(np.bincount(votes).argmax())

pred = np.array(pred)

print("Actual   :", yt)
print("Predicted:", pred)
print("Accuracy :", accuracy_score(yt, pred))